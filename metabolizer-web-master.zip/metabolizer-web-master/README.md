Metabolizer
===========

Metabolizer is a web tool for analysis of modular architecture of metabolic pathways using transcriptomic data. Metabolizer calculates impact of modules on production of metabolites.These modules are conserved part of metabolism which starts with substrate(s) and ends with a product.
